# -*- coding: utf-8 -
#
# This file is part of restkit released under the MIT license.
# See the NOTICE for more information.

version_info = (4, 2, 1)
__version__ =  ".".join(map(str, version_info))
